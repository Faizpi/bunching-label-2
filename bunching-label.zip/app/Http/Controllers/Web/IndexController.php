<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Label;
use App\Increment;

class IndexController extends Controller
{
    public function index(Request $req) {
        $user = auth()->user();
        
        $search = !is_null($req->search) || $req->search === 0;

        $labels = Label::orderBy('id', 'desc');
        if(!$user->isAdmin()) {
            $labels = $labels->where('operator_id', $user->id);
        }

        if($search) {
            $labels = $labels->where('lot_number', 'like', '%'.$req->search.'%');
        }
        $labels = $labels->paginate(10);
        return view('web.dashboard.index', compact("labels"));
    }

    public function print(Request $req) {
        $last_number = $this->getIncrement();
        $pharse = $this->pharseLastNumber($last_number);

        $user = auth()->user();
        $label = new Label;
        $label->lot_number = $req->machine_number . "" . date('ymd', strtotime($req->shift_date)) . "" . $pharse;
        $label->formated_lot_number = $req->machine_number . "-" . date('y-m-d', strtotime($req->shift_date)) . "-" . $pharse;
        $label->size = $req->size;
        $label->length = $req->length;
        $label->weight = $req->weight;
        $label->shift_date = $req->shift_date;
        $label->shift = $req->shift;
        $label->machine_number = $req->machine_number;
        $label->pitch = $req->pitch;
        $label->direction = $req->direction;
        $label->visual = $req->visual;
        $label->remark = $req->remark;
        $label->bobin_no = $req->bobin_no;
        $label->operator_id = $user->id;
        $label->save();
        $this->updateIncrement($last_number);

        // $pdf = Pdf::loadView('export.label', ['label' => $label]);
        // return $pdf->stream('label.pdf', ['Attachment' => false]);
        return view('export.label', ['label' => $label]);
    }

    public function edit($label) {
        $label = Label::find($label);
        if (!$label) {
            return redirect()->route("web.dashboard.index");
        }

        return view('web.dashboard.edit', compact("label"));
    }

    public function update(Request $req, $label) {
        $user = auth()->user();
        $label = Label::find($label);
        if (!$label) {
            return redirect()->route("web.dashboard.index");
        }

        $last_number = intval(substr("$label->lot_number", -3));
        $pharse = $this->pharseLastNumber($last_number);
        $label->lot_number = $req->machine_number . "" . date('ymd', strtotime($req->shift_date)) . "" . $pharse;
        $label->formated_lot_number = $req->machine_number . "-" . date('y-m-d', strtotime($req->shift_date)) . "-" . $pharse;
        $label->size = $req->size;
        $label->length = $req->length;
        $label->weight = $req->weight;
        $label->shift_date = $req->shift_date;
        $label->shift = $req->shift;
        $label->machine_number = $req->machine_number;
        $label->pitch = $req->pitch;
        $label->direction = $req->direction;
        $label->visual = $req->visual;
        $label->remark = $req->remark;
        $label->bobin_no = $req->bobin_no;
        $label->operator_id = $user->id;
        $label->save();

        return view('export.label', ['label' => $label]);
    }

    public function updateOnly(Request $req, $label) {
        $user = auth()->user();
        $label = Label::find($label);
        if (!$label) {
            return redirect()->route("web.dashboard.index");
        }

        $last_number = intval(substr("$label->lot_number", -3));
        $pharse = $this->pharseLastNumber($last_number);
        $label->lot_number = $req->machine_number . "" . date('ymd', strtotime($req->shift_date)) . "" . $pharse;
        $label->formated_lot_number = $req->machine_number . "-" . date('y-m-d', strtotime($req->shift_date)) . "-" . $pharse;
        $label->size = $req->size;
        $label->length = $req->length;
        $label->weight = $req->weight;
        $label->shift_date = $req->shift_date;
        $label->shift = $req->shift;
        $label->machine_number = $req->machine_number;
        $label->pitch = $req->pitch;
        $label->direction = $req->direction;
        $label->visual = $req->visual;
        $label->remark = $req->remark;
        $label->bobin_no = $req->bobin_no;
        $label->operator_id = $user->id;
        $label->save();
        
        return redirect()->route("web.dashboard.index");
    }

    public function delete($label) {
        $label = Label::find($label);
        if (!$label) {
            return redirect()->route("web.dashboard.index");
        }
        $label->delete();

        return redirect()->route('web.dashboard.index');
    }

    private function getIncrement() {
        $increment = Increment::first();
        if(!$increment) {
            return 1;
        }

        if($increment->last_number >= 4) {
            return 1;
        }

        return $increment->last_number + 1;
    }

    private function updateIncrement($last) {
        $increment = Increment::first();
        if(!$increment) {
            $increment = new Increment;
            $increment->last_number = 1;
        } else {
            $increment->last_number = $last;
        }

        $increment->save();
    }

    private function pharseLastNumber($number) {
        if($number < 10) {
            return '00'. $number;
        } else if($number >= 10 && $number < 100) {
            return '0'. $number;
        } else if ($number >= 100) {
            return $number;
        }
    }
}
